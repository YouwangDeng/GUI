#include <iostream>
#include <vector>

using namespace std;

vector<int> readVals();
vector<int> valsGT0(vector<int> v);
int findLast(vector<int> v, int target);
void printVals(vector<int> v);
void testFindLast(vector<int> v, int target);

int main() {
   vector<int> input = readVals();
   vector<int> targets;
   targets.push_back(2);
   targets.push_back(5);
   targets.push_back(0);
   for(int i = 0; i < targets.size(); ++i) {
      testFindLast(input, targets[i]);
   }
   return 0;
}

vector<int> readVals() {
   vector<int> v;
   int num;
   while(cin >> num) v.push_back(num);
   return v;
}

// returns a vector of values from v that are greater than 0
// these values are in the same relative order as they are in v.
vector<int> valsGT0(vector<int> v) {
   vector<int> filtered;
   for(int i = 0; i < v.size(); ++i) {
      if(v[i] > 0) filtered.push_back(v[i]);
   }
   return filtered;
}

// returns location of last instance of target in v or -1 if not found
int findLast(vector<int> v, int target) {
   int loc = -1;
   for(int i = 0; i < v.size(); ++i) {
      if(v[i] == target) loc = i;
   }
   return loc;
}

void testFindLast(vector<int> v, int target) {
   cout << "Vector: ";
   printVals(v);
   cout << "The last instance of " << target << " is at position " << findLast(v, target) << endl;
}

void printVals(vector<int> v) {
   for(int i = 0; i < v.size(); ++i) {
      cout << v[i] << " ";
   }
   cout << endl;
}