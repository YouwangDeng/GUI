// Name: Youwang Deng
// USC NetID: youwangd
// CSCI 455 PA5
// Fall 2018

/*
 * grades.cpp
 * A program to test the Table class.
 * How to run it:
 *      grades [hashSize]
 * 
 * the optional argument hashSize is the size of hash table to use.
 * if it's not given, the program uses default size (Table::HASH_SIZE)
 *
 */

#include "Table.h"

// cstdlib needed for call to atoi
#include <cstdlib>

using namespace std;

//headers for command methods
void cinCommand(string & command, string * & commands);
void switchCmd(string * & commands, Table * &grades);
void insertCmd(const string &key, int value, Table * &grades);
void changeCmd(const string &key, int value, Table * &grades);
void lookupCmd(const string &key, Table * &grades);
void removeCmd(const string &key, Table * &grades);
void helpCmd();


int main(int argc, char * argv[]) {
   // gets the hash table size from the command line
   int hashSize = Table::HASH_SIZE;
   Table * grades;  // Table is dynamically allocated below, so we can call
   // different constructors depending on input from the user.
   if (argc > 1) {
      hashSize = atoi(argv[1]);  // atoi converts c-string to int
      if (hashSize < 1) {
         cout << "Command line argument (hashSize) must be a positive number" 
              << endl;
         return 1;
      }
      grades = new Table(hashSize);
   }
   else {   // no command line args given -- use default table size
      grades = new Table();
   }
   grades->hashStats(cout);
   // store the whole command line in a string
   string command;
   // split the command line into commands array
   string * commands = new string[3];
   do {
      cout << "cmd>";
      getline(cin, command);
      // split the command line
      cinCommand(command, commands);
      // choose method the execute the command
      switchCmd(commands, grades);
   } while(commands[0] != "quit");
   return 0;
}

// method for splitting a string with " " 
void cinCommand(string & command, string * & commands) {
   string cmd = "";
   int index = 0;
   // traverse the string, use ' ' to seperate word
   for(char c : command) {
      if(c != ' ') {
         cmd += c;
         commands[index] = cmd;
      } else {
         index++;
         cmd = ""; 
      } 
   }
}

// choose methods for corresponding commands
void switchCmd(string * & commands, Table * &grades) { 
   string cmd = commands[0];
   if(cmd == "insert") {
      // convert command[2] string to int
      insertCmd(commands[1], stoi(commands[2]), grades);
   } else if(cmd == "change") {
      // convert command[2] string to int
      changeCmd(commands[1], stoi(commands[2]), grades);
   } else if(cmd == "lookup") {
      lookupCmd(commands[1], grades);
   } else if(cmd == "remove") {
      removeCmd(commands[1], grades);
   } else if(cmd == "print") {
      grades->printAll();
   } else if(cmd == "size") {
      cout << "The number of entries is " << grades->numEntries() << endl;
   } else if(cmd == "stats") {
      grades->hashStats(cout);
   } else if(cmd == "help") {
      helpCmd();
   } else if(cmd == "quit") {
      
   } else {
      // error handling
      cout << "ERROR: invalid command" << endl;
      helpCmd();
   }
   
}

// insert the key and value into the table
void insertCmd(const string &key, int value, Table * &grades) {
   bool success = grades->insert(key, value);
   // output the insert operation status
   if(success) {
      cout << "Insert Success!" << endl;
   } else {
      cout << "This name was already present!" << endl;
   }
}

// change the key's value in a table
void changeCmd(const string &key, int value, Table * &grades) {
   int * p = grades->lookup(key);
   // change the value if has found the key
   if(p != NULL) {
      *p = value;
      cout << "Change Success!" << endl;
   } else {
      cout << "This name was not in the table!" << endl;
   } 
}

// lookup a key in a table
void lookupCmd(const string &key, Table * &grades) {
   int *p = grades->lookup(key);
   // output the lookup operation status
   if(p != NULL) {
      cout << key << "'s score is " << *p << endl;
   } else {
      cout << "This name was not in the table!" << endl;
   }
}

// remove a key and value pair in a table
void removeCmd(const string &key, Table * &grades) {
   bool success = grades->remove(key);
   // output the remove operation status
   if(success) {
      cout << "Remove Success!" << endl;
   } else {
      cout << "This name was not in the table!" << endl;
   }
}

// help command return the commands usage of the program
void helpCmd() {
   // format the help message
   cout << "Here are the commands for the program:" << endl;
   cout << "insert name score" << endl;
   cout << "    " << "Insert this name and score in the grade table." << endl;
   cout << "change name score" << endl;
   cout << "    " << "Change the score for name." << endl;
   cout << "lookup name" << endl;
   cout << "    " << "Lookup the name, and print out his or her score." << endl;
   cout << "remove name" << endl;
   cout << "    " << "Remove this student." << endl;
   cout << "print" << endl;
   cout << "    " << "Prints out all names and scores in the table." << endl;
   cout << "size" << endl;
   cout << "    " << "Prints out the number of entries in the table." << endl;
   cout << "stats" << endl;
   cout << "    " << "Prints out statistics about the hash table at this point." << endl;
   cout << "help" << endl;
   cout << "    " << "Prints out a brief command summary." << endl;
   cout << "quit" << endl;
   cout << "    " << "Exits the program." << endl;
}