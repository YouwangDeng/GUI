// Name: Youwang Deng
// USC NetID: youwangd
// CS 455 PA5
// Fall 2018

// pa5list.cpp
// a program to test the linked list code necessary for a hash table chain

// You are not required to submit this program for pa5.

// We gave you this starter file for it so you don't have to figure
// out the #include stuff.  The code that's being tested will be in
// listFuncs.cpp, which uses the header file listFuncs.h

// The pa5 Makefile includes a rule that compiles these two modules
// into one executable.

#include <iostream>
#include <string>
#include <cassert>

using namespace std;

#include "listFuncs.h"

// test program for the list functions
int main() {
   // test the insert, print and remove methods of the list
   Node * p = new Node("abc", 1);
   insertFront("abd",2,p);
   insertFront("abe",2,p);
   printList(p);
   cout<<endl;
   removeList("abe",p);
   printList(p);
   return 0;
}
