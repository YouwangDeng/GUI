// Name: Youwang Deng
// USC NetID: youwangd
// CSCI 455 PA5
// Fall 2018


#include <iostream>

#include <cassert>

#include "listFuncs.h"

using namespace std;

Node::Node(const string &theKey, int theValue) {
   key = theKey;
   value = theValue; 
   next = NULL;
}

Node::Node(const string &theKey, int theValue, Node *n) {
   key = theKey;
   value = theValue;
   next = n;
}




//*************************************************************************
// put the function definitions for your list functions below

/** look up the key in a list
 *  if the key exists, return the ListType, otherwise return NULL
 */
ListType lookupList(const std::string &theKey, ListType list) {
   if(list == NULL) return NULL;
   ListType p = list;
   // traverse the list, and compair the key
   while(p != NULL) {
      if(p->key == theKey) return p;
      p = p->next;
   }
   return NULL;
}

// insert a pair of key and value into the head of the list
void insertFront(const std::string &theKey, int theValue, ListType &list) {
   list = new Node(theKey, theValue, list);
}

/** remove the key in the list
 *  if the key exists, remove the key and value pair, return true
 *  make no change to the list and return false
 */
bool removeList(const std::string &theKey, ListType &list) {
   if(list == NULL) return false;
   // corner case, when the head of the list has to be removed
   if(list->key == theKey) {
      list = list->next;
      return true;
   }
   // use to pointer to mark remove positon
   ListType pre = list;
   ListType cur = list->next;
   while(cur != NULL) {
      // find the matched key and remove that from the list
      if(cur->key == theKey) {
         pre->next = cur->next;
         return true;
      }
      pre = cur;
      cur = cur->next;
   }
   return false;
}

// print the key and value pairs in the list chain
void printList(ListType list) {
   ListType p = list;
   while(p != NULL) {
      cout << p->key << " " << p->value << endl;
      p = p->next;
   }
}

// return the length of the list
int lengthOfList(ListType list) {
   ListType p = list;
   int length = 0;
   // traverse the list to get the length
   while(p != NULL) {
      length++;
      p = p->next;
   }
   return length;
}