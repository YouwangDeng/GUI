#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>

using namespace std;

string getPort(int sockfd){
	struct sockaddr_in loc_addr;
	socklen_t len = sizeof(loc_addr);
	memset(&loc_addr, 0, len);
	if(getsockname(sockfd, (struct sockaddr *)&loc_addr, &len) == 0) {
		stringstream ss;
		ss << ntohs(loc_addr.sin_port);
		return ss.str();
	} else {
		perror("getsockname");
		exit(1);	
	}
}

string searchDatabase(string link_id) {
	string line;
	ifstream myfile("database.txt");
	if(myfile.is_open()) {
		while(getline(myfile, line)) {
			if(link_id == line.substr(0, line.find_first_of(" "))) {
				return line;			
			}		
		}	
	}
	return "not found";
}

int main(void) {
	/*string line;
	stringstream ss;
	fstream myfile ("database.txt", ios::in | ios::out | ios::app);
	string something = "data";
	if(myfile.is_open()) {
		myfile.seekg(0, ios_base::end);
		if(myfile.tellg() == 0) {
			myfile << "1 first line\n";
			myfile.close();
			return 0;		
		}
		myfile.seekg(-2, ios_base::end);
		bool stop = false;
		while(stop != 1) {
			char c;
			myfile.get(c);
			if((int)myfile.tellg() <= 1) {
				myfile.seekg(0);
				stop = true;		
			} else if(c == '\n') {
				stop = true;			
			} else {
				myfile.seekg(-2, ios_base::cur);			
			}
		}
		string lastline;
		getline(myfile, lastline);
		cout << "Last Line is: " << lastline << "\n";
		int link_id = atoi(lastline.substr(0, lastline.find_first_of(" ")).c_str()) + 1;
		ss.str("");
		ss << link_id;
		myfile << ss.str() << " something" <<"\n";
		myfile.close();
		
	}*/
	cout << searchDatabase("7") << "\n";
	return 0;
}
