#include <iostream>
#include <stdio.h>
#include <sstream>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <vector>
#include <math.h>
#include <iomanip>

using namespace std;

// round the number to the second decimal
double roundToTwo(double num) {
	return floor(num * 100 + 0.5) / 100;
}

// server B
int main(void) {
	struct sockaddr_storage their_addr;
	socklen_t addr_size;
	struct addrinfo hints, *res, *p;
	vector<double> v;
	int sockfd, numbytes, rv;
	char buf[1024];
	// the socket create, bind, connect and accept code is referenced from the Beej's tutorial
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	// get address info
	if(rv = getaddrinfo("127.0.0.1", "22666", &hints, &res) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;	
	}
	// build UDP socket and bind port number 22666 to the socket
	for(p = res; p != NULL; p = p->ai_next) {
		if((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
			perror("listener:socket");
			continue;		
		}
		if(bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("listener:bind");
			continue;		
		}
		break;
	}
	// error checking
	if(p == NULL) {
		fprintf(stderr, "listener: failed to bind socket\n");
		return 2;
	}
	freeaddrinfo(res);
	cout << "The Server B is up and running using UDP on port <22666>.\n";
	const char *word;
	stringstream ss;
	// infinite loop to receive message from aws server
	while(true) {
		addr_size = sizeof their_addr;
		// receice compute request from aws server
		if((numbytes = recvfrom(sockfd, buf, 1023, 0, (struct sockaddr *)&their_addr, &addr_size)) == -1) {
			perror("recvfrom");
			exit(1);		
		}
		buf[numbytes] = '\0';
		string parameters = buf;
		int begin, end;
		end = -1;
		string link_id;
		string file_size;
		string signal_power;
		// init vector
		v.clear();
		// extract data from compute data from request
		for(int i = 0; i < 7; i++) {
			begin = end + 1;
			end = parameters.find_first_of(" ", begin);
			if(i == 0) {
				link_id = parameters.substr(begin,end - begin);			
			}
			if(i == 1) {
				file_size = parameters.substr(begin,end - begin);			
			}
			if(i == 2) {
				signal_power = parameters.substr(begin,end - begin);			
			}
			v.push_back(atof(parameters.substr(begin,end - begin).c_str()));	
		}
		// print request infomation
		cout << "The Server B received link information: link <" + link_id + ">, file size <" + file_size + ">, and signal power <" + signal_power + ">\n";
		// compute delays
		double Tt = v[1]/(v[3] * 1000 * log10(1 + v[2]/v[6])/log10(2));
		double Tp = v[4]/v[5] * 1000;
		double delay = Tt + Tp;
		// round delays
		Tt = roundToTwo(Tt);
		Tp = roundToTwo(Tp);
		delay = roundToTwo(delay);
		ss.str("");
		// set precisions for delays
		ss << fixed << setprecision(2) << Tt << "," << Tp << "," << delay << ",";
		string data = ss.str() + "\n";
		word = data.c_str();
		cout << "The Server B finished the calculation for link <" + link_id + ">\n";
		// send delays to aws server
		sendto(sockfd, word, strlen(word), 0, (const struct sockaddr *)&their_addr, sizeof(their_addr));
		// print finish message
		cout << "The Server B finished sending the output to AWS\n";
	}
	return 0;
}
