#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <vector>

using namespace std;

// write link information to database
string writeToDatabase(string data) {
	string line;
	stringstream ss;
	// open the file
	fstream myfile ("database.txt", ios::in | ios::out | ios::app);
	if(myfile.is_open()) {
		// code referenced from stackoverflow
		// get the last line in the file
		myfile.seekg(0, ios_base::end);
		// the file is empty
		if(myfile.tellg() == 0) {
			myfile << "1" + data;
			myfile.close();
			return "1";		
		}
		// skip the "\n"
		myfile.seekg(-2, ios_base::end);
		bool stop = false;
		// move to the beginning of the last line
		while(stop != 1) {
			char c;
			myfile.get(c);
			if((int)myfile.tellg() <= 1) {
				myfile.seekg(0);
				stop = true;		
			} else if(c == '\n') {
				stop = true;			
			} else {
				myfile.seekg(-2, ios_base::cur);			
			}
		}
		// get the last line
		string lastline;
		getline(myfile, lastline);
		// extract the link id in the last line, add 1 to it
		int link_id = atoi(lastline.substr(0, lastline.find_first_of(" ")).c_str()) + 1;
		// write the new link id and the link data into the file
		ss.str("");
		ss << link_id;
		myfile << ss.str() << data;
		myfile.close();
	}
	// return the new link id
	return ss.str();
}

// search in the database
string searchDatabase(string link_id) {
	string line;
	// open the file
	ifstream myfile("database.txt");
	if(myfile.is_open()) {
		// read line by line and check whether the link id exists
		while(getline(myfile, line)) {
			if(link_id == line.substr(0, line.find_first_of(" "))) {
				// the link id is found
				return line;			
			}		
		}	
	}
	return "";
}

// server A
int main(void) {
	string request, message, FUNC;
	vector<string> v;
	// the socket create, bind, connect and accept code is referenced from the Beej's tutorial
	struct sockaddr_storage their_addr;
	socklen_t addr_size;
	struct addrinfo hints, *res, *p;
	int sockfd, numbytes, rv;
	char buf[1024];
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	// get address info
	if(rv = getaddrinfo("127.0.0.1", "21666", &hints, &res) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;	
	}
	// build UDP socket and bind port number 21666 to the socket
	for(p = res; p != NULL; p = p->ai_next) {
		if((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
			perror("listener:socket");
			continue;		
		}
		if(bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("listener:bind");
			continue;		
		}
		break;
	}
	// error checking
	if(p == NULL) {
		fprintf(stderr, "listener: failed to bind socket\n");
		return 2;
	}
	freeaddrinfo(res);
	// boot up message
	cout << "The Server A is up and running using UDP on port <21666>.\n";
	// init the datadase txt when the server is up
	ofstream database ("database.txt");
	database.close();
	const char *word;
	// infinite loop to receive message from aws server
	while(true) {
		addr_size = sizeof their_addr;
		// receive message from aws server
		if((numbytes = recvfrom(sockfd, buf, 1023, 0, (struct sockaddr *)&their_addr, &addr_size)) == -1) {
			perror("recvfrom");
			exit(1);		
		}
		buf[numbytes] = '\0';
		request = buf;
		// extract the request type
		int begin = 0;
		int end = request.find_first_of(",", 0);
		FUNC = request.substr(begin, end - begin);
		v.clear();
		string new_link_id;
		string searchResult;
		// handle the write request
		if(FUNC == "write") {
			cout << "The Server A received input for writing\n";
			// extract link info
			for(int i = 0; i < 4; i++) {
				begin = end + 1;
				end = request.find_first_of(",", begin);
				v.push_back(request.substr(begin,end - begin));	
			}
			// build link data
			string data = " " + v[0] + " " + v[1] + " " + v[2] + " " + v[3] + " \n";
			// write link data into database
			new_link_id = writeToDatabase(data);	
			word = "ACK\n";	
		} else {// handle the search request
			// extract the lind id
			begin = end + 1;
			end = request.find_first_of(",", begin);
			string link_id = request.substr(begin,end - begin);
			cout << "The Server A received input <" + link_id + "> for computing\n";
			// search in the database
			searchResult = searchDatabase(link_id);
			// the link id is found
			if(searchResult.length() > 0) {
				searchResult = "1 " + searchResult + "\n";
				word = searchResult.c_str();	
			} else {// the link id is not found
				word = "0\n";
			}
			
		}
		// send response to aws server
		sendto(sockfd, word, strlen(word), 0, (const struct sockaddr *)&their_addr, sizeof(their_addr));
		// print finish message
		if(FUNC == "write") {
			cout << "The Server A wrote link <" + new_link_id + "> to database\n";
		} else {
			if(searchResult.length() > 0) {
				cout << "The Server A finished sending the search result to AWS\n";			
			} else {
				cout << "Link ID not found\n";		
			}	
		}
	}
	return 0;
}
