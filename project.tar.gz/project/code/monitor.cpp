#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>

using namespace std;

// monitor
int main(int argc, char *argv[]) {

	struct sockaddr_storage their_addr;
	socklen_t addr_size;
	struct addrinfo hints, *res, *p;
	int sockfd, numbytes, rv;
	char buf[1024];
	// the socket create, bind, connect and accept code is referenced from the Beej's tutorial
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	// boot up message
	cout << "The monitor is up and running.\n";
	// get aws server address infomation
	if(rv = getaddrinfo("127.0.0.1", "25666", &hints, &res) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;	
	}
	// build TCP socket and connect to aws server
	for(p = res; p != NULL; p = p->ai_next) {
		if((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
			perror("listener:socket");
			continue;		
		}
		if(connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("listener:connect");
			continue;		
		}
		break;
	}
	// error checking
	if(p == NULL) {
		fprintf(stderr, "listener: failed to connect to aws server\n");
		return 2;
	}
	freeaddrinfo(res);
	// infinite receive message from aws server using TCP socket
	while(true) {
		// receive message from aws server
		numbytes = recv(sockfd, buf, 1023, 0);
		buf[numbytes]= '\0';
		// print received message
		cout << buf;	
	}
	close(sockfd);	
	return 0;
}
