#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h> 

using namespace std;

// client
int main(int argc, char *argv[]) {
	struct sockaddr_storage their_addr;
	socklen_t addr_size;
	struct addrinfo hints, *res, *p;
	int sockfd, numbytes, rv;
	char buf[1024];
	// the socket create, bind, connect and accept code is referenced from the Beej's tutorial
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	// boot up message
	cout << "The client is up and running.\n";
	// get server address info
	if(rv = getaddrinfo("127.0.0.1", "24666", &hints, &res) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;	
	}
	// build TCP socket and connect to aws server using TCP
	for(p = res; p != NULL; p = p->ai_next) {
		if((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
			perror("listener:socket");
			continue;		
		}
		if(connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfd);
			perror("listener:connect");
			continue;		
		}
		break;
	}
	// error checking
	if(p == NULL) {
		fprintf(stderr, "listener: failed to connect to aws server\n");
		return 2;
	}
	freeaddrinfo(res);
	// store request into variables
	string FUNC = argv[1];
	string BW;
	string LENGTH;
	string VELOCITY;
	string NOISEPOWER;
	string LINK_ID;
	string SIZE;
	string SIGNALPOWER;
	string request;
	if(FUNC == "write") {
		BW = argv[2];
		LENGTH = argv[3];
		VELOCITY = argv[4];
		NOISEPOWER = argv[5];
		// build client request
		request = FUNC + "," + BW + "," + LENGTH + "," + VELOCITY + "," + NOISEPOWER+ ",";
		// print send message
		cout << "The client sent write operation to AWS\n"; 		
	} else {
		LINK_ID = argv[2];
		SIZE = argv[3];
		SIGNALPOWER = argv[4];
		// build client request	
		request = FUNC + "," + LINK_ID + "," + SIZE + "," + SIGNALPOWER+ ",";
		// print send message
		cout << "The client sent link ID=<" + LINK_ID + ">, size=<" + SIZE + ">, and power=<" + SIGNALPOWER + "> to AWS\n";
	}
	const char *word = request.c_str();
	// send request to aws server
	send(sockfd, word, strlen(word), 0);
	// receive responce from aws server
	numbytes = recv(sockfd, buf, 1023, 0);
	buf[numbytes]= '\0';
	// print response
	cout << buf;
	// close TCP connection
	close(sockfd);	
	return 0;
}
