#include <iostream>
#include <stdio.h>
#include <sstream>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <vector>

using namespace std;

// aws server
int main(void) {

	// variables to store message infomation
	vector<string> v;
	string request;
	string FUNC;
        string message;
	string repA;
	string repB;
	// the socket create, bind, connect and accept code is referenced from the Beej's tutorial
	struct sockaddr_storage their_addrUDP, their_addrCTCP, their_addrMTCP;
	socklen_t addr_sizeUDP, addr_sizeTCP;
	struct addrinfo hintsUDP, *serverAUDP, *clientUDP, *p, *serverBUDP, hintsTCP, *serverCTCP, *serverMTCP;
	int sockfdAUDP, numbytesUDP, numbytesTCP,sockfdBUDP, sockfdCTCP, sockfdMTCP, newfdCTCP, newfdMTCP;
	char buf[1024];
	memset(&hintsUDP, 0, sizeof hintsUDP);
	hintsUDP.ai_family = AF_INET;
	hintsUDP.ai_socktype = SOCK_DGRAM;
	
	memset(&hintsTCP, 0, sizeof hintsTCP);
	hintsTCP.ai_family = AF_INET;
	hintsTCP.ai_socktype = SOCK_STREAM;
	// get UDP address info
	getaddrinfo("127.0.0.1", "21666", &hintsUDP, &serverAUDP);
	getaddrinfo("127.0.0.1", "22666", &hintsUDP, &serverBUDP);
	getaddrinfo("127.0.0.1", "23666", &hintsUDP, &clientUDP);
	// get TCP address info
	getaddrinfo("127.0.0.1", "24666", &hintsTCP, &serverCTCP);
	getaddrinfo("127.0.0.1", "25666", &hintsTCP, &serverMTCP);

	
	// boot up message
	cout << "The AWS is up and running.\n";
	// create client TCP socket and bind port number 24666
	for(p = serverCTCP; p != NULL; p = p->ai_next) {
		if((sockfdCTCP = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
			perror("listener:socket");
			continue;		
		}
		if(bind(sockfdCTCP, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfdCTCP);
			perror("listener:bind");
			continue;		
		}
		break;
	}
	// error checking
	if(p == NULL) {
		fprintf(stderr, "listener: failed to bind socket on client TCP\n");
		return 2;
	}

	if(listen(sockfdCTCP, 10) == -1) {
		perror("listener");
		exit(1);	
	}

	freeaddrinfo(serverCTCP);
	// create monitor TCP socket and bind port number 25666
	for(p = serverMTCP; p != NULL; p = p->ai_next) {
		if((sockfdMTCP = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
			perror("listener:socket");
			continue;		
		}
		if(bind(sockfdMTCP, p->ai_addr, p->ai_addrlen) == -1) {
			close(sockfdMTCP);
			perror("listener:bind");
			continue;		
		}
		break;
	}
	// error checking
	if(p == NULL) {
		fprintf(stderr, "listener: failed to bind socket on monitor TCP\n");
		return 2;
	}

	if(listen(sockfdMTCP, 10) == -1) {
		perror("listener");
		exit(1);	
	}
	freeaddrinfo(serverMTCP);
	addr_sizeTCP = sizeof their_addrMTCP;
	// acccept TCP connections from monitor
	newfdMTCP = accept(sockfdMTCP, (struct sockaddr *)&their_addrMTCP, &addr_sizeTCP);
	if(newfdMTCP == -1) {
		perror("accept");
		exit(1);		
	}
	// infinite loop to accept connections from client side
	while(true) {
		// during each loop build two UDP sockets
		sockfdAUDP = socket(serverAUDP->ai_family, serverAUDP->ai_socktype, serverAUDP->ai_protocol);
		sockfdBUDP = socket(serverBUDP->ai_family, serverBUDP->ai_socktype, serverBUDP->ai_protocol);
		addr_sizeTCP = sizeof their_addrCTCP;
		// accept TCP connection from client
		newfdCTCP = accept(sockfdCTCP, (struct sockaddr *)&their_addrCTCP, &addr_sizeTCP);
		if(newfdCTCP == -1) {
			perror("accept");
			continue;		
		}
		// receive message from client
		numbytesTCP = recv(newfdCTCP, buf, 1023, 0);
		buf[numbytesTCP]= '\0';
		request = buf;
		// extract request function type
		int begin = 0;
		int end = request.find_first_of(",", 0);
		FUNC = request.substr(begin, end - begin);
		// print receive message
		cout << "The AWS received operation <" + FUNC + "> from the client using TCP over port <24666>\n";
		// init vector
		v.clear();
		// extract message from request according to request type
		if(FUNC == "write") {
			for(int i = 0; i < 4; i++) {
				begin = end + 1;
				end = request.find_first_of(",", begin);
				v.push_back(request.substr(begin,end - begin));	
			}		
		} else {
			for(int i = 0; i < 3; i++) {
				begin = end + 1;
				end = request.find_first_of(",", begin);
				v.push_back(request.substr(begin,end - begin));	
			}
		}
		// bind aws UDP socket to 23666
		for(p = clientUDP; p != NULL; p = p->ai_next) {
			if(bind(sockfdAUDP, p->ai_addr, p->ai_addrlen) == -1) {
				perror("listener:bind");
				continue;		
			}
			break;
		}
		// error checking
		if(p == NULL) {
			fprintf(stderr, "listener: failed to bind serverA UDP socket\n");
			return 2;
		}
		// build monitor message
		if(FUNC == "write") {
			message = "The monitor received BW=<" + v[0] + ">, L=<" + v[1] + ">, V=<" + v[2] + "> and P=<" + v[3] + "> from the AWS" +"\n";
		} else {
			message = "The monitor received link ID=<" + v[0] + ">, size=<" + v[1] + ">, power=<" + v[2] + "> from the AWS" +"\n";
		}	
		const char *word = message.c_str();
		// send message to monitor	
		send(newfdMTCP, word, strlen(word), 0);
		cout << "The AWS sent operation <" + FUNC + "> and arguments to the monitor using TCP over port <25666>\n";
		message = request + "\n";
		word = message.c_str();
		// send request to server A using UDP
		sendto(sockfdAUDP, word, strlen(word), 0, serverAUDP->ai_addr, serverAUDP->ai_addrlen);
		cout << "The AWS sent operation <" + FUNC + "> to Backend-Server A using UDP over port <23666>\n";
		// receive response from server A using UDP
		numbytesUDP = recvfrom(sockfdAUDP, buf, 1023, 0, serverAUDP->ai_addr, &serverAUDP->ai_addrlen);
		buf[numbytesUDP] = '\0';
		repA = buf;
		// check response type
		// the response type is a write operation response
		if(repA.find_first_of("ACK") != -1) {
			// print receive message
			cout << "The AWS received response from Backend-Server A for writing using UDP over port <23666>\n";
			// close UDP connection to server A
			close(sockfdAUDP);
			const char *writeRep = "The write operation has been completed successfully\n";
			// send write succcessful message to client and monitor using TCP
			send(newfdCTCP, writeRep, strlen(writeRep), 0);	
			send(newfdMTCP, writeRep, strlen(writeRep), 0);
			cout << "The AWS sent write response to the monitor using TCP over port <25666>\n";
			cout << "The AWS sent result to client for operation <write> using TCP over port <24666>\n";
		} else if(repA.find_first_of("1") != -1) {// the response type is compute and the link id is found
			cout << "The AWS received link information from Backend-Server A using UDP over port <23666>\n";
			// close UDP connection to server A
			close(sockfdAUDP);
			// bind aws UDP socket to 23666
			for(p = clientUDP; p != NULL; p = p->ai_next) {
				if(bind(sockfdBUDP, p->ai_addr, p->ai_addrlen) == -1) {
					perror("listener:bind");
					continue;		
				}
				break;
			}
			// error checking
			if(p == NULL) {
				fprintf(stderr, "listener: failed to bind serverB UDP socket\n");
				return 2;
			}
			end = -1;
			// extract link information response from server A
			for(int i = 0; i < 6; i++) {
				begin = end + 1;
				end = repA.find_first_of(" ", begin);
				if(i > 1) {
					v.push_back(repA.substr(begin,end - begin));	
				}
			}
			string computeData;
			// build the data message needed for computation 
			for(int i = 0; i < 7; i++) {
				computeData += v[i] + " ";
			}
			computeData += "\n";
			word = computeData.c_str();
			// send the data message to server B using UDP
			sendto(sockfdBUDP, word, strlen(word), 0, serverBUDP->ai_addr, serverBUDP->ai_addrlen);
			cout << "The AWS sent link ID=<" + v[0] + ">, size=<" + v[1] + ">, power=<" + v[2] + ">, and link information to Backend-Server B using UDP over port <23666>\n";
			// receive computation response from server B
			numbytesUDP = recvfrom(sockfdBUDP, buf, 1023, 0, serverBUDP->ai_addr, &serverBUDP->ai_addrlen);
			buf[numbytesUDP] = '\0';
			cout << "The AWS received outputs from Backend-Server B using UDP over port <23666>\n";
			// close UDP connection to server B
			close(sockfdBUDP);
			repB = buf;
			vector<string> delays;
			end = -1;
			// extract delay response from server B
			for(int i = 0; i < 3; i++) {
				begin = end + 1;
				end = repB.find_first_of(",", begin);
				delays.push_back(repB.substr(begin,end - begin));	
			}
			// build delay message
			string resultToClient = "The delay for link <" + v[0] + "> is <" + delays[2] + ">ms\n";
			word = resultToClient.c_str();
			// send delay message to client
			send(newfdCTCP, word, strlen(word), 0);
			cout << "The AWS sent result to client for operation <compute> using TCP over port <24666>\n";
			// build delay message
			string resultToMonitor = "The result for link <" + v[0] + ">:\nTt = <" + delays[0] + ">ms\nTp = <"+ delays[1] + ">ms\nDelay = <" + delays[2] + ">ms\n";
			
			word = resultToMonitor.c_str();
			// send delay message to monitor
			send(newfdMTCP, word, strlen(word), 0);
			cout << "The AWS sent compute results to the monitor using TCP over port <25666>\n";
			
		} else {// link id not found
			close(sockfdAUDP);
			cout << "Link ID not found\n";
			word = "Link ID not found\n";
			send(newfdCTCP, word, strlen(word), 0);
			send(newfdMTCP, word, strlen(word), 0);
		}
		// close client TCP connection
		close(newfdCTCP);	
	}
	close(newfdMTCP);
	freeaddrinfo(serverAUDP);
	freeaddrinfo(serverBUDP);
	freeaddrinfo(clientUDP);
	return 0;
}
